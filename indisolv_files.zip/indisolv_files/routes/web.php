<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'HomeController@index')->name('home');

Route::get('/category/{category}', 'CategoryController@index');

Route::get('/news/{id}', 'NewsController@index');

Route::get('/inditutorial', 'Indi\InditutorialController@index')->name('inditutorial');	

Route::get('/indiinsider', 'Indi\IndiinsiderController@index')->name('indiinsider');	

Route::get('/indilifestyle', 'Indi\IndilifestyleController@index')->name('indilifestyle');

Route::get('/article/{id}', 'HomeController@show');

Route::get('/about', 'AboutController@index')->name('about');

Route::get('/addon', 'AddonController@index')->name('addon');

Route::get('/search','HomeController@search')->name('search');

Auth::routes();

Route::group(['prefix' => 'dashboard'], function(){
	Route::get('/', 'DashboardController@index')->name('dashboard');

	Route::post('/inditutorial', 'Indi\InditutorialController@store')->name('store_tutorial');
	Route::post('/indiinsider', 'Indi\IndiinsiderController@store')->name('store_insider');
	Route::post('/indilifestyle', 'Indi\IndilifestyleController@store')->name('store_lifestyle');

	Route::get('/inditutorial', 'DashboardController@inditutorial')->name('admin_inditutorial');
	Route::get('/indiinsider', 'DashboardController@indiinsider')->name('admin_indiinsider');
	Route::get('/indilifestyle', 'DashboardController@indilifestyle')->name('admin_indilifestyle');

	Route::get('/{id}/delete', 'DashboardController@delete');

	Route::get('/{id}/edit', 'DashboardController@editArticle');

	Route::post('/{id}/edit', 'DashboardController@update');

	Route::get('/page_analytic', 'PageanalyticController@index')->name('page_analytic');

	Route::get('/users', 'UserController@index')->name('users');

	Route::get('user/{id}/delete', 'UserController@delete');

	Route::get('user/{id}/makeAdmin', 'UserController@makeAdmin');

	Route::get('user/{id}/removeAdmin', 'UserController@removeAdmin');

});

