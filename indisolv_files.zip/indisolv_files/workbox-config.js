module.exports = {
  globDirectory: 'public/',
  globPatterns: [
    '**/*.{css,js,json,html,txt,PNG,jpeg}','offline.html'
  ],
  swDest: 'public/service-worker.js',
  globIgnores: [
		'../workbox-cli-config.js',
		'photos/**',
    'images/**'
  ]
};

