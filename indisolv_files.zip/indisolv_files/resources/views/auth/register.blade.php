@extends('layouts.theme')

@section('content')

    <section id="tutorial" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2></h2>
                              <!-- <span class="line-bar">...</span> -->
                         </div>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        
                        <!-- CONTACT FORM HERE -->
                        <form id="contact-form" role="form" action="{{ route('register') }}" method="post">
                            @csrf
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="name" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">{{ __('Name') }}</label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                    @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="form-group row">
                              <div class="col-md-4">
                                    <label for="password" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">{{ __('E-Mail Address') }}</label>
                              </div>

                              <div class="col-md-8 col-sm-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                              </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="password" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">{{ __('Password') }}</label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="password" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">{{ __('Confirm Password') }}</label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                </div>
                            </div>

                            <div class="form-group row">
                                  <div class="col-md-offset-4 col-md-4 col-sm-12">
                                       <input type="submit" class="form-control" name="submit" value="{{ __('Register') }}">
                                  </div>
                            </div>

                         </form>
                    </div>
               </div>
          </div>
     </section>
      <!-- FOOTER -->
     <footer data-stellar-background-ratio="0.5" style="padding-top: 10px; padding-bottom: 10px;">
          <div class="container">
             <div class="footer-bottom" style="margin-top: 1.5em;">
                  <div class="col-md-6 col-sm-5">
                       <div class="copyright-text"> 
                            <p>Copyright &copy; 2020 Indisolv</p>
                       </div>
                  </div>
                  <div class="col-md-6 col-sm-7">
                       <div class="phone-contact"> 
                            <p><span>Your Solutive Assistant</span></p>
                       </div>
                       <ul class="social-icon">
                            <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                            <li><a href="#" class="fa fa-twitter"></a></li>
                            <li><a href="#" class="fa fa-instagram"></a></li>
                       </ul>
                  </div>
             </div>
          </div>
     </footer>
@endsection
