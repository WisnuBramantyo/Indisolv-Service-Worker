@extends('layouts.theme')
<style type="text/css">
</style>
@section('content')
    <section id="tutorial" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2></h2>
                              <!-- <span class="line-bar">...</span> -->
                         </div>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        
                        <!-- CONTACT FORM HERE -->
                        <form id="contact-form" role="form" action="{{ route('login') }}" method="post">
                            @csrf
                              <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="email" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">{{ __('E-Mail Address') }}</label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                    @error('email')
                                    <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                    </span>
                                    @enderror
                                </div>
                              </div>

                              <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="password" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">{{ __('Password') }}</label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                              </div>
                              <div class="form-group row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }} style="height: 0px;">

                                        <label class="form-check-label" for="remember" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">
                                            {{ __('Remember Me') }}
                                        </label>
                                    </div>
                                </div>
                              </div>
                              <div class="form-group row">
                                  <div class="col-md-offset-4 col-md-4 col-sm-12">
                                       <input type="submit" class="form-control" name="submit" value="{{ __('Login') }}">
                                  </div>
                              </div>
                              <div class="form-group row col-md-offset-4 col-md-4 col-sm-12">
                                <a class="btn btn-link" href="{{ route('register') }}" style="color: white;" onMouseOver="this.style.color='#F00'" onMouseOut="this.style.color='#fff'">
                                    Doesn't have account?
                                </a>
                              </div>

                         </form>
                    </div>
               </div>
          </div>
     </section>
      <!-- FOOTER -->
     <footer data-stellar-background-ratio="0.5" style="padding-top: 10px; padding-bottom: 10px;">
          <div class="container">
             <div class="footer-bottom" style="margin-top: 1.5em;">
                  <div class="col-md-6 col-sm-5">
                       <div class="copyright-text"> 
                            <p>Copyright &copy; 2020 Indisolv</p>
                       </div>
                  </div>
                  <div class="col-md-6 col-sm-7">
                       <div class="phone-contact"> 
                            <p><span>Your Solutive Assistant</span></p>
                       </div>
                       <ul class="social-icon">
                            <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                            <li><a href="#" class="fa fa-twitter"></a></li>
                            <li><a href="#" class="fa fa-instagram"></a></li>
                       </ul>
                  </div>
             </div>
          </div>
     </footer>
@endsection
