@extends('layouts.theme')
<style type="text/css">
    .category-wrapper {
        padding-top:70px;
    }

    @media(min-width:768px) {
    .category-wrapper {
        padding: 50px;
        width:100%;
        background: #ea2e49;
    }

</style>
<!-- <link href="{{ asset('css/media_query.css') }}" rel="stylesheet" type="text/css"/> -->
<link href="{{ asset('css/style_1.css') }}" rel="stylesheet" type="text/css"/>

@section('content')
<div class="category-wrapper"></div> 
     <section id="blog" data-stellar-background-ratio="0.5">
          <div class="container">

        <div class="row">
            <div class="col-md-12 col-sm-12 animate-box" data-animate-effect="fadeInLeft">
                 <div class="section-title">
                      <h2>Online Article</h2>
                      <span class="line-bar">...</span>
                 </div>
            </div>
        </div>
        <div class="row mx-0">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                @foreach($data as $news)
                <div class="row" style="margin-bottom: 25px; margin-top:25px; background: #fff; -webkit-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); -moz-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); border-radius: 3px; text-align: left;">
                    <div class="col-md-5">
                        <div class="fh5co_hover_news_img">
                        @if($news->urlToImage != NULL)
                            <div class="fh5co_news_img"><img src="{{ url($news->urlToImage) }}" alt=""/></div>
                        @else
                            <div class="fh5co_news_img"><img src="" alt=""/></div>
                        @endif
                        <div></div>
                        </div>
                    </div>
                    <div class="col-md-7 animate-box">
                        <h4><a href="{{url($news->url)}}">{{ $news->title }}</a></h4>
                        <small><i class="fa fa-clock-o"></i> {{ $news->author . ' - ' .date('d M y', strtotime($news->publishedAt)) }}</small>
                        @if($news->content != NULL)
                        <p style="font-size: 0.9em;"> {{ substr($news->content, 0, 260) . '...' }} </p>
                        @elseif($news->description != NULL)
                        <p> {{ $news->description }} </p>
                        @else
                        <p> No Description. </p>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
            <div class="col-md-4 col-sm-4 section-title">
                <h3>Tags</h3>
                <span class="line-bar">___</span>
            </div>
            <div class="fh5co_tags_all">
                <a href="{{ url('inditutorial') }}" class="fh5co_tagg">Tutorial</a>
                @if(Request::url() === url('category/indihome'))
                <a href="{{ url('category/indihome?page=1') }}" class="fh5co_tagg" style="background-color: #ea2e49">Indihome</a>
                @else
                <a href="{{ url('category/indihome?page=1') }}" class="fh5co_tagg">Indihome</a>
                @endif
                @if(Request::url() === url('category/technology'))
                <a href="{{ url('category/technology?page=1') }}" class="fh5co_tagg" style="background-color: #ea2e49">Teknologi</a>
                @else
                <a href="{{ url('category/technology?page=1') }}" class="fh5co_tagg">Teknologi</a>
                @endif
                @if(Request::url() === url('category/internet'))
                <a href="{{ url('category/internet?page=1') }}" class="fh5co_tagg" style="background-color: #ea2e49">Internet</a>
                @else
                <a href="{{ url('category/internet?page=1') }}" class="fh5co_tagg">Internet</a>
                @endif
                @if(Request::url() === url('category/telepon'))
                <a href="{{ url('category/telepon?page=1') }}" class="fh5co_tagg" style="background-color: #ea2e49">Telepon</a>
                @else
                <a href="{{ url('category/telepon?page=1') }}" class="fh5co_tagg">Telepon</a>
                @endif
                @if(Request::url() === url('category/tv'))
                <a href="{{ url('category/tv?page=1') }}" class="fh5co_tagg" style="background-color: #ea2e49">TV</a>
                @else
                <a href="{{ url('category/tv?page=1') }}" class="fh5co_tagg">TV</a>
                @endif
            </div>
        </div>
        <div class="row mx-0">
            <div class="col-12 text-center pb-4 pt-4">
                <a href="{{ url()->current() . '?page=1' }}" class="btn_pagging">1</a>
                <a href="{{ url()->current() . '?page=2' }}" class="btn_pagging">2</a>
                <a href="{{ url()->current() . '?page=3' }}" class="btn_pagging">3</a>
                <a href="{{ url()->current() . '?page=4' }}" class="btn_pagging">4</a>
            </div>
        </div>
    </div>
</div>

<script src="{{ asset('js/main.js') }}"></script>


@endsection