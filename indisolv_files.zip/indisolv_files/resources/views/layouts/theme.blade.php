<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" class="no-js">
<head>
     <!-- <link rel="shortcut icon" type="image/x-icon" href="{{ asset('images/logo-small.png') }}" /> -->
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Styles -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <title>{{ config('app.name', 'Indisolv') }}</title>
    <meta name="description" content="Indihome AI-Powered Chatbot">
    <meta name="keywords" content="indihome chatbot">
    <meta name="author" content="Indisolv">

    <link href="{{ asset('manifest.json') }}" rel="manifest">
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/magnific-popup.css') }}" rel="stylesheet">
    <!-- <link href="{{ asset('css/font-awesome.min.css') }}" rel="stylesheet"> -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
      integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

     <!-- MAIN CSS -->
    <link href="{{ asset('css/templatemo-style.css') }}" rel="stylesheet">
    <style type="text/css">
      df-messenger {
        --df-messenger-user-message: #b3dbfb;
      }
    </style>
</head>

<body>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="indisolv.com" class="navbar-brand" style="padding-top: 0px; margin-top: 5px;"><img src="{{asset('images/indisolv.gif')}}" height="45" alt="Logo Indisolv"></a>
                    <!-- <a href="{{route('home')}}" class="navbar-brand">Indisolv</a> -->
               </div>

               <!-- MENU LINKS -->
               <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-nav-first">
                         <li><a href="{{route('home')}}" class="">Home</a></li>
                         <!-- <li><a href="#about" class="">Promos</a></li> -->
                         <li><a href="{{ route('addon')}}" class="">Add On</a></li>
                         <li><a href="{{ route('inditutorial') }}" class="">Tutorial</a></li>
                         <li><a href="{{ url('category/technology?page=1') }}" class="">Article</a></li>
                         <li><a href="{{ route('about')}}" class="">About</a></li>
                         <!-- Add to Homescreen Prompt -->
<!--                          <li>
                            <a href="#" onclick="addToHomeScreen()">
                               <span class="uk-margin-small-right" data-uk-icon="icon: plus"></span> 
                               Add to Home Screen
                            </a>
                         </li> -->
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                        <!-- <li><a href="#"><i class="fa fa-facebook-square"></i></a></li> -->
                        <!-- <li><a href="#"><i class="fa fa-twitter"></i></a></li> -->
                        <li><a href="#" data-toggle="modal" data-target="#modal-search"><i class="fa fa-search"></i></a></li>
                        @guest
                        <li class="section-btn"><a href="{{route('login')}}" data-toggle="" data-target="">Sign in / Join</a></li>
                        @else
                        <li class="section-btn"><a href="#" data-toggle="modal" data-target="#modal-logout">Logout</a></li>
                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                        </form>
                        @endif
                    </ul>
               </div>

          </div>
    </section>
    @yield('content')

    <div class="modal fade" id="modalSearchForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header text-center">
            <h5 class="modal-title" align="text-center">Search Indi Article</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ route('search')}}" method="get" enctype="multipart/form-data">
          <div class="modal-body mx-3">
              <input type="text" name="keyword" required="true" id="keyword" class="form-control">
          </div>
          <div class="modal-footer d-flex justify-content-center">
                         <input type="submit" name='publish' class="btn btn-danger" value = "Search"/>
          </div>
      </form>
        </div>
      </div>
    </div>

     <!-- MODAL -->
    <section class="modal fade" id="modal-search" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
           <div class="modal-content modal-popup">

                <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                     </button>
                </div>

                <div class="modal-body">
                     <div class="container-fluid">
                          <div class="row">

                               <div class="col-md-12 col-sm-12">
                                    <div class="modal-title">
                                         <h2>Search Article</h2>
                                    </div>
                                    <form action="{{ route('search')}}" method="get" enctype="multipart/form-data">
                                        <div class="modal-body mx-3">
                                            <input type="text" class="form-control" name="keyword" id="keyword" placeholder="Mohon masukan kata kunci pencarian" required>
                                        </div>
                                        <input type="submit" name='publish' class="btn btn-danger" value = "Search"/>
                                    </form>
                               </div>
                          </div>
                     </div>
                </div>

           </div>
      </div>
    </section>

    <section class="modal fade" id="modal-logout" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
           <div class="modal-content modal-popup">

                <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                     </button>
                </div>

                <div class="modal-body">
                     <div class="container-fluid">
                          <div class="row">

                               <div class="col-md-12 col-sm-12">
                                    <div class="modal-title">
                                         <h2>Are you sure to logout?</h2>
                                    </div>
                                        <div class="modal-body mx-3">
                                        <a class="btn btn-info" style="width:60px" title="Kembali" data-dismiss="modal">No</a>
                                        <a class="btn btn-danger" href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Yes</a>
                                        </div>
                               </div>
                          </div>
                     </div>
                </div>

           </div>
      </div>
    </section>

     <!-- Script -->
    <script src="{{ asset('js/jquery.js') }}"></script>
    <script src="{{ asset('js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/jquery.stellar.min.js') }}"></script>
    <script src="{{ asset('js/jquery.magnific-popup.min.js') }}"></script>
    <!-- <script src="j{{ asset('js/smoothscroll.js') }}"></script> -->
    <script src="{{ asset('js/custom.js') }}"></script>    
   <script src="https://www.gstatic.com/dialogflow-console/fast/messenger/bootstrap.js?v=1"></script>
    <df-messenger
      intent="WELCOME"
      chat-title="Indisolv"
      agent-id="56595828-5c61-4288-b33b-3eb7753e4958"
      language-code="id"
      chat-icon="{{ asset('images/chat-us.png') }}"
    ></df-messenger>
    <script type="text/javascript">
      // var url = "{{asset('service-worker.js') }}";
     
      //add to homescreen prompt
     //  var deferredPrompt;
     //  window.addEventListener('beforeinstallprompt', function(event) {
     //    event.preventDefault();
     //    deferredPrompt = event;
     // //    return false;
     //  });

      function addToHomeScreen() {
        if (deferredPrompt) {
          deferredPrompt.prompt();
          deferredPrompt.userChoice.then(function (choiceResult) {
            console.log(choiceResult.outcome);
            if (choiceResult.outcome === 'dismissed') {
              console.log('User cancelled installation');
            } else {
              console.log('User added to home screen');
            }
          });
          deferredPrompt = null;
        }
      }
    </script>
    <script>

     //  window.addEventListener('beforeinstallprompt', (e) => {
     //    // Prevent the mini-infobar from appearing on mobile
     //    e.preventDefault();
     //    // Stash the event so it can be triggered later.
     //    deferredPrompt = e;
     //    // Update UI notify the user they can install the PWA
     //    // showInstallPromotion();
     //  });

     //  window.addEventListener('appinstalled', (evt) => {
     //    // Log install to analytics
     //    console.log('Success installing the PWA application');
     //  });

      $(document).ready(function() {
          // YOUR CODE (NOT RELATED TO DIALOGFLOW MESSENGER)
          window.addEventListener('dfMessengerLoaded', function (event) {
              $r1 = document.querySelector("body >df-messenger");
              $r2 = $r1.shadowRoot.querySelector("div > df-messenger-chat");
              var style = document.createElement( 'style' );
              var styleR = document.createElement( 'style' );
              style.innerHTML = 'div.chat-wrapper[opened="true"] { height: 70%; }';
              // styleR.innerHTML = 'div.chat-wrapper[opened="true"] { z-index:-1; position:relative; }';

              $r2.shadowRoot.appendChild( style );
              // $r1.shadowRoot.appendChild( styleR );

              // MORE OF YOUR DIALOGFLOW MESSENGER CODE
          });
          // addToHomescreen();
      });
    </script>
</body>
</html>
