@extends('layouts.theme')
<style type="text/css">
    .addon-wrapper {
        padding-top:70px;
    }

    @media(min-width:768px) {
    .addon-wrapper {
        padding: 50px;
        width:100%;
        background: #ea2e49;
    }
	
    .addon-thumb h3 {
		margin-top:10px;
	}

</style>
<!-- <link href="{{ asset('css/media_query.css') }}" rel="stylesheet" type="text/css"/> -->
<!-- <link href="{{ asset('css/style_1.css') }}" rel="stylesheet" type="text/css"/> -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->
@section('content')
<div class="addon-wrapper"></div>
     <!-- WORK -->
     <section id="work" data-stellar-background-ratio="0.5" style="margin-top: 20px; padding-top: 0px;">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         	  <h2 style="margin-top: 0px;margin-bottom: 10px;">Add On Indihome</h2>
                              <p>Lengkapi lndiHome Anda dengan beragam pilihan layanan tambahan sesuai dengan kebutuhan Anda.</p>
                    </div>
                </div>
                <div class="row">
                	<div class="col-md-3 col-sm-12">
                    <h2>Kategori Internet</h2></div><div class="col-md-9 col-sm-12"><hr style="margin-top: 35px;" /></div>
					<!-- <div class="border-top my-3"></div> -->
				</div>
				<div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/wifiidseamless" target="_blank">
                                   <img src="{{asset('images/banner-wifiidseamless.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Wifi.id Seamless</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Wifi.id Seamless</h4>
						 <small>Nikmati akses internetan dengan kecepatan hingga 100Mbps di lokasi yang tersedia jaringan Wifi.id.</small>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/speedondemand" target="_blank">
                                   <img src="{{asset('images/banner-sod.jpg')}}" class="img-responsive" alt="Work">
                                   <div class="work-info">
				                        <h3>Speed on Demand</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Speed on Demand</h4>
                         <small>Tambah kecepatan internet secara temporer sesuai dengan keinginan Anda. Bebas tingkatkan kecepatan internet anda.</small>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/upgradespeed" target="_blank">
                                   <img src="{{asset('images/banner-upgradespeed.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Upgrade Speed</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Upgrade Speed</h4>
                         <small>Upgrade kecepatan internet Anda dengan Upgrade Speed. Tersedia kecepatan mulai dari 20Mbps hingga 300Mbps.</small>
                    </div>

               </div>
                <div class="row">
                	<div class="col-md-3 col-sm-12">
                    <h2>Kategori TV</h2></div><div class="col-md-9 col-sm-12"><hr style="margin-top: 35px;" /></div>
					<!-- <div class="border-top my-3"></div> -->
				</div>
				<div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/minipack" target="_blank">
                                   <img src="{{asset('images/banner-minipack.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Minipack Channel TV</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Minipack Channel TV</h4>
						 <small>Nonton berbagai serial TV, tayangan edukatif untuk anak dan film favorit keluarga Anda dengan beragam pilihan dari channel-channel populer!</small>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/hybridbox" target="_blank">
                                   <img src="{{asset('images/banner-hybridbox.jpg')}}" class="img-responsive" alt="Work">
                                   <div class="work-info">
				                        <h3>Hybrid Box (STB) Tambahan dan PLC</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Hybrid Box (STB) Tambahan dan PLC</h4>
                         <small>Punya TV lebih dari satu di rumah, jadi bisa nonton beragam tayangan IndiHome TV dalam waktu bersamaan.</small>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/tvstorage" target="_blank">
                                   <img src="{{asset('images/banner-tvstorage.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>TV Storage</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>TV Storage</h4>
                         <small>Rekam dan simpan tayangan favorit Anda di IndiHome TV jadi lebih banyak hingga 50GB.</small>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/iflix" target="_blank">
                                   <img src="{{asset('images/banner-iflix.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Iflix</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Iflix</h4>
                         <small>Nikmati bebas nonton hiburan Asia terbaik, dengan ragam tayangan series dan film favorit Anda hingga 12 bulan.</small>
                    </div>
                </div>
                <div class="row" style="margin-top: 20px;">
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/catchplay" target="_blank">
                                   <img src="{{asset('images/banner-catchplay.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>CATCHPLAY+</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>CATCHPLAY+</h4>
                         <small>Miliki bioskop pribadi selama 24 jam sehari! Cara terbaik menonton film terbaru atau serial drama terbaik.</small>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/edukids" target="_blank">
                                   <img src="{{asset('images/banner-edukids.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>EduKids.id</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>EduKids.id</h4>
                         <small>Mengontrol tayangan untuk anak jadi lebih mudah dan dapat disesuaikan dengan usia anak Anda.</small>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/vidio" target="_blank">
                                   <img src="{{asset('images/banner-vidio.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Vidio</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Vidio</h4>
                         <small>Layanan streaming film pilihan dengan konten premium dan hiburan eksklusif menarik!</small>
                    </div>
					<div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/molatv" target="_blank">
                                   <img src="{{asset('images/banner-molatv.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Mola TV App</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Mola TV App</h4>
                         <small>Beragam tayangan berkualitas, dari film layar lebar hingga liga ternama untuk hiburan keluarga Anda.</small>
                    </div>
               </div>
                <div class="row">
                	<div class="col-md-3 col-sm-12">
                    <h2>Kategori Lainnya</h2></div><div class="col-md-9 col-sm-12"><hr style="margin-top: 35px;" /></div>
					<!-- <div class="border-top my-3"></div> -->
				</div>
				<div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/cloudstorage" target="_blank">
                                   <img src="{{asset('images/banner-cloudstorage.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Cloud Storage</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Cloud Storage</h4>
						 <small>Layanan penyimpanan data online untuk berbagai jenis gadget yang bisa digunakan kapan saja dengan akses internet.</small>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/benefit-games" target="_blank">
                                   <img src="{{asset('images/banner-benefitgames.jpg')}}" class="img-responsive" alt="Work">
                                   <div class="work-info">
				                        <h3>Benefit Games</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>Benefit Games</h4>
                         <small>Dapatkan berbagai exclusive items, in game currency, double experience dan masih banyak lagi dari game-game favorit.</small>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/indihomestudy" target="_blank">
                                   <img src="{{asset('images/banner-indihomestudy.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>IndiHome Study</h3>
                                   </div>
                              </a>
                         </div>
                         <h4>IndiHome Study</h4>
                         <small>Akses berbagai materi pelajaran dan konten edukasi mulai dari tingkat SD hingga SMA dengan praktis!</small>
                    </div>
                    <div class="col-md-3 col-sm-6 col-xs-6 addon-thumb">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="https://indihome.co.id/addon/smooa" target="_blank">
                                   <img src="{{asset('images/banner-smooa.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Smooa</h4>
                                   </div>
                              </a>
                         </div>
                         <h4>Smooa</h3>
                         <small>Mudahnya berbagi kuota internet mobile bersama anggota keluarga saat di rumah atau di mana saja.</small>
                    </div>
               </div>
          </div>
     </section>

          <!-- FOOTER -->
     <footer data-stellar-background-ratio="0.5" style="margin-top:0px; padding-top: 0px;">
          <div class="container">
               <div class="row">        

                    <div class="col-md-12 col-sm-12">
                         <div class="footer-bottom">
                              <div class="col-md-6 col-sm-5">
                                   <div class="copyright-text"> 
                                        <p>Copyright &copy; 2020 IndiSolv</p>
                                   </div>
                              </div>
                              <div class="col-md-6 col-sm-7">
                                   <div class="phone-contact"> 
                                        <p>Chat IndiSolv <span>AI-Powered Bot</span></p>
                                   </div> 
                                   <ul class="social-icon">
                                        <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                        <li><a href="#" class="fa fa-twitter"></a></li>
                                        <li><a href="#" class="fa fa-instagram"></a></li>
                                        <li><a href="#" onclick="addToHomeScreen()" class="fa fa-home"> Add to Homescreen</a></li>
                                   </ul>
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>
</div>

<!-- <script src="{{ asset('js/main.js') }}"></script> -->


@endsection