@extends('layouts.admin')

@section('content')

<div class="container">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Email</th>
      <th scope="col">Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  	@foreach($users as $user)
    <tr> 
      <th scope="row">{{$user -> email}}</th>
      <td>{{$user -> name }}</td>
      <td>
        @if(!$user->isAdmin())
        <a href="{{ action('UserController@makeAdmin', $user->id) }}"><button type="button" class="btn btn-warning">Make Admin</button></a>
        @else
        <a href="{{ action('UserController@removeAdmin', $user->id) }}"><button type="button" class="btn btn-warning">Remove Admin</button></a>
        @endif
        <a class="btn btn-danger" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $user->id;?>">Delete</a>
      </td>
    </tr>

     <div class="modal fade" id="modaldelete<?php echo $user->id;?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $user->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <a class="btn btn-info btn-simple pull-left" style="width:60px" title="Kembali" data-dismiss="modal">Tidak</a>
                                    <a class="btn btn-danger btn-simple pull-right" style="width:60px" title="Hapus" href="{{ action('UserController@delete', $user->id) }}">Ya</a>
                                </div>
                          
                            </div>
                        </div>
                    </div>

    @endforeach
  </tbody>
</table>

	{{ $users->links()}}	
 </div>
@endsection
