@extends('layouts.admin')

@section('content')

<div class="container">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Category</th>
      <th scope="col">Author</th>
      <th scope="col">Description</th>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
  	@foreach($articles as $article)
    <tr> 
      <th scope="row"><a href="{{ url('/article/'.$article->id)}}">{{$article -> title}}</a></th>
      <td>{{$article -> category }}</td>
      <td>{{ $article -> author}}</td>
      <td>{{ $article -> description}}</td>
      <td><a href="{{ action('DashboardController@editArticle', $article->id) }}"><button type="button" class="btn btn-warning">Edit</button></a></td>
        <td><center><a class="btn btn-danger" data-placement="bottom" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $article->id;?>">Delete</a></td>
    </tr>

     <div class="modal fade" id="modaldelete<?php echo $article->id;?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $article->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <a class="btn btn-info btn-simple pull-left" style="width:60px" title="Kembali" data-dismiss="modal">Tidak</a>
                                    <a class="btn btn-danger btn-simple pull-right" style="width:60px" title="Hapus" href="{{ action('DashboardController@delete', $article->id) }}">Ya</a>
                                </div>
                          
                            </div>
                        </div>
                    </div>

    @endforeach
  </tbody>
</table>

	{{ $articles->links()}}	
 </div>
@endsection
