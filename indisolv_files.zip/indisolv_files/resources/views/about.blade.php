@extends('layouts.theme')
<style type="text/css">
    .about-wrapper {
        padding-top:70px;
    }

    @media(min-width:768px) {
    .about-wrapper {
        padding: 50px;
        width:100%;
        background: #ea2e49;
    }

</style>
<!-- <link href="{{ asset('css/media_query.css') }}" rel="stylesheet" type="text/css"/> -->
<!-- <link href="{{ asset('css/style_1.css') }}" rel="stylesheet" type="text/css"/> -->

@section('content')

    <!-- HOME -->
    <section id="home" data-stellar-background-ratio="0.5">
          <div class="overlay"></div>
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <div class="home-info">
                              <h1>Helping to solve your problem yourself.</h1>
                              <a href="#about" class="btn section-btn smoothScroll">Chat IndiSolv Now!</a>
                              <span>
                                   TALK TO OUR AI-POWERED BOT
                                   <small>For any problem</small>
                              </span>
                         </div>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="home-video">
                              <div class="embed-responsive embed-responsive-16by9">
                                   <!-- <iframe src="https://www.youtube.com/embed/AqcjdkPMPJA" frameborder="0" allowfullscreen></iframe> -->
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>

     <!-- ABOUT -->
     <section id="about" data-stellar-background-ratio="0.5" style="padding-top: 0px;">
          <div class="container">
               <div class="row">

                    <div class="col-md-5 col-sm-6">
                         <div class="about-info">
                              <div class="section-title">
                                   <h2>What Customer Want?</h2>
                                   <span class="line-bar">...</span>
                              </div>
                              <p>Customer validation yang kami lakukan menemukan fakta menarik. Dimana dari 115 pelanggan Indihome, 92.2%-nya ingin menyelesaikan gangguan Indihome secara mandiri.</p>
                              <p>Akan tetapi hal ini terhambat oleh pengetahuan dan panduan mengenai troubleshoot Indihome yang masih rendah.</p>
                         </div>
                    </div>

                    <div class="col-md-3 col-sm-6">
                         <div class="about-info skill-thumb">

                              <strong>Self-Troubleshoot</strong>
                                   <span class="pull-right">92.5%</span>
                                        <div class="progress">
                                             <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100" style="width: 92.5%;"></div>
                                        </div>

                              <strong>Tutorial Indihome</strong>
                                   <span class="pull-right">96.5%</span>
                                        <div class="progress">
                                             <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width: 96.5%;"></div>
                                        </div>

                              <strong>Low Tech. Knowledge</strong>
                                   <span class="pull-right">72.2%</span>
                                        <div class="progress">
                                             <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 72.2%;"></div>
                                        </div>

<!--                               <strong>Bad Technician</strong>
                                   <span class="pull-right">27.8%</span>
                                        <div class="progress">
                                             <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 27.8%;"></div>
                                        </div> -->
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-12">
                         <div class="about-image">
                              <img src="{{asset('images/about-image.jpg')}}" class="img-responsive" alt="">
                         </div>
                    </div>
                    
               </div>
          </div>
     </section>

     <!-- WORK -->
     <section id="work" data-stellar-background-ratio="0.5" style="background: #f0f0f0;">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2>Our Team</h2>
                              <span class="line-bar">...</span>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="{{asset('images/azka.jpg')}}" class="image-popup">
                                   <img src="{{asset('images/azka.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Azka Aditya</h3>
                                        <small>Chief Technology Officers</small>
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="{{asset('images/zaky.jpg')}}" class="image-popup">
                                   <img src="{{asset('images/zaky.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Abdullah Zaky</h3>
                                        <small>Chief Executive Officers</small>
                                   </div>
                              </a>
                         </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                         <!-- WORK THUMB -->
                         <div class="work-thumb">
                              <a href="{{asset('images/sarah.jpg')}}" class="image-popup">
                                   <img src="{{asset('images/sarah.jpg')}}" class="img-responsive" alt="Work">

                                   <div class="work-info">
                                        <h3>Sarah Karimah</h3>
                                        <small>Chief Marketing Officers</small>
                                   </div>
                              </a>
                         </div>
                    </div>

               </div>
          </div>
     </section>

     <!-- FOOTER -->
     <footer data-stellar-background-ratio="0.5" style="margin-top:0px; padding-top: 0px;">
          <div class="container">
               <div class="row">        

                    <div class="col-md-12 col-sm-12">
                         <div class="footer-bottom">
                              <div class="col-md-6 col-sm-5">
                                   <div class="copyright-text"> 
                                        <p>Copyright &copy; 2020 IndiSolv</p>
                                   </div>
                              </div>
                              <div class="col-md-6 col-sm-7">
                                   <div class="phone-contact"> 
                                        <p>Chat Us <span>AI-Powered Bot</span></p>
                                   </div>
                                   <ul class="social-icon">
                                        <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                        <li><a href="#" class="fa fa-twitter"></a></li>
                                        <li><a href="#" class="fa fa-instagram"></a></li>
                                        <li><a href="#" onclick="addToHomeScreen()" class="fa fa-home"> Add to Homescreen</a></li>
                                   </ul>
                              </div>
                         </div>
                    </div>
                    
               </div>
          </div>
     </footer>
<!-- <script src="{{ asset('js/main.js') }}"></script> -->


@endsection