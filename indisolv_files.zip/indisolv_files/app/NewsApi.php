<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NewsApi extends Model
{
	protected $table = "tb_articles";
	protected $fillable = ['author','title','description','url','urlToImage','publishedAt','content','category'];
}
