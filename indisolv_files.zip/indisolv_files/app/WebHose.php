<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WebHose extends Model
{
    protected $table = "tb_webhose";
	protected $fillable = ['author','title','description','url','urlToImage','publishedAt','content','category'];
}
