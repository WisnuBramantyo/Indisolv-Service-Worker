<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SourceApi extends Model
{
    protected $table = "tb_source";
    protected $fillable = ['id', 'category', 'description', 'url', 'language', 'country'];
}
