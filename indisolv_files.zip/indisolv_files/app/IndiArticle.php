<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IndiArticle extends Model
{
    //
}
