<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\IndiArticle;
use \Illuminate\Support\Str;
use App\NewsApi;
use GuzzleHttp\Client;
use App\WebVisitor;


class HomeController extends Controller
{
    public function index(){
    	$newest = IndiArticle::orderBy('created_at', 'DESC')
    								->first();
    	$recents = IndiArticle::orderBy('created_at', 'DESC')
    								->limit(2)
    								->offset(1)
    								->get();
    	$insiders = IndiArticle::where('category', 'insider')
                                    ->orderBy('created_at', 'DESC')
                                    ->limit(5)
                                    ->get();
       	$tutorials = IndiArticle::where('category', 'tutorial')
                                     ->orderBy('created_at', 'DESC')
                                     ->limit(5)
                                     ->get();
        $newest->description = Str::limit($newest->description, 100);

        WebVisitor::find(1)->increment('visitor');

        $news =  $this->getNewsApi("Technology", "publishedAt", 25);
        $popularnews = $this->getNewsApi("", "popularity", 10);

        return view('home')
        			->with('recents', $recents)
        			->with('newest', $newest)
        			->with('tutorials', $tutorials)
        			->with('insiders', $insiders)
        			->with('data', $news)
                    ->with('popular', $popularnews);
    }


   public function show($id){
        $article = IndiArticle::find($id);
        $article->increment('visitor');
        $recent = IndiArticle::orderBy('created_at', 'DESC')->limit(5)->get();
        return view('news')->with('article', $article)->with('recents', $recent);
    }


    public function search(Request $request){
            WebVisitor::find(1)->increment('visitor');
            $result = IndiArticle::where('title', 'like', '%' . $request->get('keyword')  . '%')
                                    ->orderBy('created_at', 'DESC')
                                    ->simplePaginate(5);

            $recent = IndiArticle::orderBy('created_at', 'DESC')->limit(5)->get();
            
            return view('indi.indiarticle')
                        ->with('indiarticles', $result)
                        ->with('recentarticles', $recent)
                        ->with('title', "Search Result");
    }



    private function getNewsApi($category, $params, $pageSize) {
        return $this->directNewsApi($category, $params, $pageSize);
    }

    private function getWebHose() {
        return $this->directWebHose();
    }

    private function directNewsApi($category = "", $params, $pageSize) {
        $client = new Client();
        $req = $client->request('GET', env('NEWS_API_URL'), [
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json',
            'query' => [
                'country' => 'id',
                'pageSize' => $pageSize,
                'page' => 1,
                'apiKey' => env('NEWS_API_KEY'),
                'sortBy' => $params,
                'category' => $category
            ],
        ]);
        $stream   = $req->getBody();
        $contents = json_decode($stream->getContents());
        $articles = collect($contents->articles);
        return $articles;
    }
}
