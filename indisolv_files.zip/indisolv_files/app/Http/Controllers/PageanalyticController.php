<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\IndiArticle;
use App\WebVisitor;

class PageAnalyticController extends Controller
{
   public function index()
    {
    	$web_visitor = WebVisitor::find(1)->visitor;
        $articles = IndiArticle::orderBy('visitor', 'DESC')->paginate(5);
        $article_visitor = IndiArticle::all()->sum('visitor');
        $total_visitor = $web_visitor + $article_visitor;
        return view('admin.page_analytic')->with('articles', $articles)->with('total_visitor', $total_visitor)->with('web_visitor',$web_visitor)->with('article_visitor', $article_visitor);
    }

}
