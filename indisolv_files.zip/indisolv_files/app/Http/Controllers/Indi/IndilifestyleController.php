<?php

namespace App\Http\Controllers\Indi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\IndiArticle as Lifestyle;
use DateTime;
use App\WebVisitor;

class IndiLifestyleController extends Controller
{
    	public function index(){
    		 WebVisitor::find(1)->increment('visitor');
			$lifestyles = Lifestyle::where('category', 'lifestyle')
							->orderBy('created_at', 'DESC')
							->simplePaginate(5);
							
			$recent = Lifestyle::orderBy('created_at', 'DESC')->limit(5)->get();


			return view('indi.indiarticle')
						->with('indiarticles', $lifestyles)
						->with('recentarticles', $recent)
                        ->with('title', "IndiLifestyle");
		}

        public function store(Request $request){
	    	$uploadOk = 1;
    		$target_dir = "upload/indi/insider/images";
    		$target_file = $target_dir . basename($_FILES["image"]["name"]);
    		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    		$dt = new DateTime();
			$fileName =  $dt->format('Ymd_his') . "-". basename($_FILES["image"]["name"]);
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir."/".$fileName)) {
            	//todo            	
            }
     
	    	$lifestyle = new Lifestyle();
    		$lifestyle->author = auth()->user()->name;
    		$lifestyle->user_id = auth()->user()->id;
            $lifestyle->category = "lifestyle";
	    	$lifestyle->title = $request->get('title');
    		$lifestyle->description = $request->get('description');
    		$lifestyle->urlToImage = $target_dir.'/'.$fileName;
    		$lifestyle->content = $request->get('content'); 

    		$lifestyle->save();

    		return redirect('indilifestyle');
    }

    public function edit(){

    }

    public function delete(){

    }
}
