<?php

namespace App\Http\Controllers\indi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\IndiArticle;

class IndiapiController extends Controller
{
    public function getInsiders(){
    	$insiders = IndiArticle::where('category', 'insider')
                                    ->orderBy('created_at', 'DESC')
                                    ->simplePaginate(25);
        return $insiders;
    }

    public function getTutorials(){
    	$tutorials = IndiArticle::where('category', 'tutorial')
                                    ->orderBy('created_at', 'DESC')
                                    ->simplePaginate(25);
        return $tutorials;
    }

    public function getLifestyles(){
    	$lifestyles = IndiArticle::where('category', 'lifestyle')
                                    ->orderBy('created_at', 'DESC')
                                    ->simplePaginate(25);
        return $lifestyles;
    }
    
    public function fillUrl(){
        $IndiArticle = IndiArticle::all();
        foreach ($IndiArticle as $indi){
            $indi->url = '/article/'.$indi->id;
            $indi->save();
             }
    return $IndiArticle;
    }
}
