<?php

namespace App\Http\Controllers\indi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\IndiArticle as Insider;
use DateTime;
use App\WebVisitor;

class IndiInsiderController extends Controller
{

		public function index(){
             WebVisitor::find(1)->increment('visitor');
			$insiders = Insider::where('category', 'insider')
                                    ->orderBy('created_at', 'DESC')
                                    ->simplePaginate(5);

            $recent = Insider::orderBy('created_at', 'DESC')->limit(5)->get();
			
            return view('indi.indiarticle')
                        ->with('indiarticles', $insiders)
                        ->with('recentarticles', $recent)
                        ->with('title', "IndiInsider");
		}

        public function store(Request $request){
	    	$uploadOk = 1;
    		$target_dir = "upload/indi/insider/images";
    		$target_file = $target_dir . basename($_FILES["image"]["name"]);
    		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    		$dt = new DateTime();
			$fileName =  str_replace(" ", "-", $dt->format('Ymd_his') . "-". basename($_FILES["image"]["name"]));
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir."/".$fileName)) {
            	//todo            	
            }
     
	    	$insider = new Insider();
    		$insider->author = auth()->user()->name;
    		$insider->user_id = auth()->user()->id;
            $insider->category = "insider";
	    	$insider->title = $request->get('title');
    		$insider->description = $request->get('description');
    		$insider->urlToImage = $target_dir.'/'.$fileName;
    		$insider->content = $request->get('content'); 

    		$insider->save();

    		return redirect('indiinsider');
    }


    public function delete(){

    }

}
