<?php

namespace App\Http\Controllers\indi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\IndiArticle as Tutorial;
use DateTime;
use App\WebVisitor;

class IndiTutorialController extends Controller
{

		public function index(){
             WebVisitor::find(1)->increment('visitor');
			$tutorials = Tutorial::where('category', 'tutorial')
                                            ->orderBy('created_at', 'DESC')
                                            ->simplePaginate(5);
            $recent = Tutorial::orderBy('created_at', 'DESC')->limit(5)->get();
            
			return view('indi.indiarticle')
                        ->with('indiarticles', $tutorials)
                        ->with('recentarticles', $recent)
                        ->with('title', "IndiTutorial");
		}

        public function store(Request $request){
	    	$uploadOk = 1;
    		$target_dir = "upload/indi/tutorial/images";
    		$target_file = $target_dir . basename($_FILES["image"]["name"]);
    		$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    		$dt = new DateTime();
			$fileName =  $dt->format('Ymd_his') . "-". basename($_FILES["image"]["name"]);
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir."/".$fileName)) {
            	//todo            	
            }
     
	    	$tutorial = new Tutorial();
    		$tutorial->author = auth()->user()->name;
    		$tutorial->user_id = auth()->user()->id;
            $tutorial->category = "tutorial";
	    	$tutorial->title = $request->get('title');
    		$tutorial->description = $request->get('description');
    		$tutorial->urlToImage = $target_dir.'/'.$fileName;
    		$tutorial->content = $request->get('content'); 

    		$tutorial->save();

    		return redirect('inditutorial');
    }

}
