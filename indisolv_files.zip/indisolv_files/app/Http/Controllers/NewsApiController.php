<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\NewsApi;
use GuzzleHttp\Client;
use Carbon\Carbon;

class NewsApiController extends Controller
{
	protected $category;
	public function index(Request $request) {
		if ($request->category != 'all') {
			return NewsApi::get()->where('category', $request->category);
		} else {
			return NewsApi::all();
		}
	}

	public function cacheNews($category) {
		$this->category = $category;
		$client = new Client();
		$req = $client->request('GET', env('NEWS_API_URL'), [
			'Accept'       => 'application/json',
			'Content-Type' => 'application/json',
			'query' => [
				'category' => $this->category,
				'country' => 'id',
				'pageSize' => 100,
				'apiKey' => env('NEWS_API_KEY')
			],
		]);
		$stream   = $req->getBody();
		$contents = json_decode($stream->getContents());
		$articles = collect($contents->articles);

		$this->deleteCategory($this->category);	
		$articles->each(function ($article) {
			$ng_article = NewsApi::create(
				[
					'author'         => $article->author,
					'title'          => $article->title,
					'description'    => $article->description,
					'url'            => $article->url,
					'urlToImage'     => $article->urlToImage,
					'content'		 => $article->content,
					'category'		 => $this->category,
					'publishedAt'    => Carbon::parse($article->publishedAt)
				]);
		});
	}

	public function truncateArticles() {
		return NewsApi::truncate();
	}

	public function deleteCategory($category) {
		return DB::table('tb_articles')->where('category', $category)->delete();
	}

	public function cacheAllCategories() {
		$this->cacheNews('technology');
	}
}
