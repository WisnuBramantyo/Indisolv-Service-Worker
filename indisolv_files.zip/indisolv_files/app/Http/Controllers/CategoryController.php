<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\NewsApi;
use App\WebHose;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\WebVisitor;


class CategoryController extends Controller
{
    protected $category;
    protected $allArticles = array();
    public function index($category, Request $request) {
        WebVisitor::find(1)->increment('visitor');
        return view('category')->with('data',$this->getNews($category, $request));
        // return response($this->getNews($category, $request));
    }

    private function getNews($category, Request $request) {
    	if ($category == 'indihome' || $category == 'internet' || $category == 'telepon' || $category == 'tv') {
            return $this->directTitleNewsApi($category, $request);
    	} else {
    		// return NewsApi::where('category', $category)->simplePaginate(5);
            return $this->directNewsApi($category, $request);
    	}
    }

    public function articles(Request $request) {
        $category = $request->category;
        if ($category == 'indihome' || $category == 'internet' || $category == 'telepon' || $category == 'tv') {
        //     return WebHose::where('category', $category)->get();
        // } else {
        //     return NewsApi::where('category', $category)->get();
        // }
            return $this->directTitleNewsApi($category, $request);
        } else {
            // return NewsApi::where('category', $category)->simplePaginate(5);
            return $this->directNewsApi($category, $request);
        }
    }

    private function directNewsApi($category, Request $request) {
        $client = new Client();
        $req = $client->request('GET', env('NEWS_API_URL'), [
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json',
            'query' => [
                'category' => $category,
                'country' => 'id',
                'pageSize' => 25,
                'page' => $request->page,
                'apiKey' => env('NEWS_API_KEY')
            ],
        ]);
        $stream   = $req->getBody();
        $contents = json_decode($stream->getContents());
        $articles = collect($contents->articles);
        return $articles;
    }

    private function directTitleNewsApi($category, Request $request) {
        $client = new Client();
        $req = $client->request('GET', env('NEWS_API_TITLE_URL'), [
            'Accept'       => 'application/json',
            'Content-Type' => 'application/json',
            'query' => [
                'qInTitle' => $category,
                'language' => 'id',
                'pageSize' => 25,
                'page' => $request->page,
                'apiKey' => env('NEWS_API_KEY')
            ],
        ]);
        $stream   = $req->getBody();
        $contents = json_decode($stream->getContents());
        $articles = collect($contents->articles);
        return $articles;
    }
}