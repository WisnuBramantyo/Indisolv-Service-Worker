<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
class UserController extends Controller
{
    public function index(){
    	$users = User::query()->paginate(10);
    	return view('admin.user')->with('users', $users);
    }

    public function delete($id){
    	User::find($id)->delete();
    	return back();
    }

    public function makeAdmin($id){
    	$user = config('roles.models.defaultUser')::find($id);
    	$user -> attachRole(1);
    	return back();
    }

    public function removeAdmin($id){
    	$user = config('roles.models.defaultUser')::find($id);
    	$user -> detachRole(1);
    	return back();
    }
}
