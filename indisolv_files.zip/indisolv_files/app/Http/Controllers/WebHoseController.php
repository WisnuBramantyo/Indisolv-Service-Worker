<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\WebHose;
use GuzzleHttp\Client;
use Carbon\Carbon;

class WebHoseController extends Controller
{
	protected $category;
	public function index(Request $request) 
	{
		if ($request->category != 'all') {
			return WebHose::get()->where('category', $request->category);
		} else {
			return WebHose::all();
		}
	}

	public function cacheNews($category) {
		$this->category = $category;
		$client = new Client();
		$request = $client->request('GET', env('WEBHOSE_API_URL'), [
		'Accept'       => 'application/json',
		'Content-Type' => 'application/json',
		'query' => [
			'token' => env('WEBHOSE_API_KEY'),
			'format' => 'json',
			'sort' => 'published',
			'latest' => true,
			'q' => 'site_category:' . $this->category . ' ' . 'thread.country:ID'
		],
	]);
	
	$stream   = $request->getBody();
	$contents = json_decode($stream->getContents());
	$articles = collect($contents->posts);

	$this->deleteCategory($this->category);	
	$articles->each(function ($article) {
		$wh_article = WebHose::create([
			'author'         => $article->author,
			'title'          => $article->title,
			'description'    => substr(str_replace("\r\n","",strip_tags($article->text, '')), 0, 500),
			'url'            => $article->url,
			'urlToImage'     => $article->thread->main_image,
			'content'		 => substr(str_replace("\r\n","",strip_tags($article->text, '')), 0, 500),
			'category'		 => $this->category,
			'publishedAt'    => Carbon::parse($article->published)
		]);
	});
}

public function truncateArticles() {
	return WebHose::truncate();
}

public function deleteCategory($category) {
	return DB::table('tb_webhose')->where('category', $category)->delete();
}

public function cacheAllCategories() {
	$this->cacheNews('travel');
	$this->cacheNews('fashion');
	$this->cacheNews('vehicles');
}
}
