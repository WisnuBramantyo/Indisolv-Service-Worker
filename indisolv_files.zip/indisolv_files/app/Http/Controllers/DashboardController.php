<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\IndiArticle;
use DateTime;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('role:admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $articles = IndiArticle::orderBy('created_at', 'DESC')->paginate(10);
        return view('dashboard')->with('articles', $articles);
    }


    public function indiTutorial(){
        return view('admin.create_inditutorial');
    }

    public function indiInsider(){
        return view('admin.create_indiinsider');
    }

    public function indiLifestyle(){
        return view('admin.create_indilifestyle');
    }

    public function editArticle($id){
        $article = IndiArticle::find($id);
        return view('admin.edit_article')->with('article', $article);
    }

    public function update(Request $request, $id){
            $article = IndiArticle::find($id);

            $uploadOk = 1;
            $target_dir = "upload/indi/".$article->category."/images";
            $target_file = $target_dir . basename($_FILES["image"]["name"]);
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            $dt = new DateTime();
            $fileName = str_replace(" ", "-", $dt->format('Ymd_his') . "-". basename($_FILES["image"]["name"]));
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_dir."/".$fileName)) {
                //todo              
            }
     
            $article->author = auth()->user()->name;
            $article->user_id = auth()->user()->id;
            $article->title = $request->get('title');
            $article->description = $request->get('description');
            if (basename($_FILES["image"]["name"]) != "") {
                $article->urlToImage = $target_dir.'/'.$fileName;
            }
            $article->content = $request->get('content'); 

            $article->save();
            return Redirect('/dashboard');
    }

    public function delete($id){
        $article = IndiArticle::find($id);
        $target_file = $article->urlToImage;
        if($target_file != "")
            unlink($target_file);
        IndiArticle::find($id)->delete();
        return Redirect('/dashboard');
    }

}
