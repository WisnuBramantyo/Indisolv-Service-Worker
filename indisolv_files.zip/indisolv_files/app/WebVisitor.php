<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WebVisitor extends Model
{
    //
}
