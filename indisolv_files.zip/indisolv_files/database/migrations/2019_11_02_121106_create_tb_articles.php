<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTbArticles extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tb_articles', function (Blueprint $table) {
            $table->increments('id');
            $table->string('author')->nullable();
            $table->string('title');
            $table->string('description', 2000)->nullable();
            $table->string('url');
            $table->string('urlToImage', 2000)->nullable();
            $table->string('content', 2000)->nullable();
            $table->string('category');
            $table->timestamp('publishedAt');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tb_articles');
    }
}
