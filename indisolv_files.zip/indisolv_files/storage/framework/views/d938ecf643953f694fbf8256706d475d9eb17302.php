

<?php $__env->startSection('content'); ?>

<div class="container">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Email</th>
      <th scope="col">Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr> 
      <th scope="row"><?php echo e($user -> email); ?></th>
      <td><?php echo e($user -> name); ?></td>
      <td>
        <?php if(!$user->isAdmin()): ?>
        <a href="<?php echo e(action('UserController@makeAdmin', $user->id)); ?>"><button type="button" class="btn btn-warning">Make Admin</button></a>
        <?php else: ?>
        <a href="<?php echo e(action('UserController@removeAdmin', $user->id)); ?>"><button type="button" class="btn btn-warning">Remove Admin</button></a>
        <?php endif; ?>
        <a class="btn btn-danger" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $user->id;?>">Delete</a>
      </td>
    </tr>

     <div class="modal fade" id="modaldelete<?php echo $user->id;?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $user->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <a class="btn btn-info btn-simple pull-left" style="width:60px" title="Kembali" data-dismiss="modal">Tidak</a>
                                    <a class="btn btn-danger btn-simple pull-right" style="width:60px" title="Hapus" href="<?php echo e(action('UserController@delete', $user->id)); ?>">Ya</a>
                                </div>
                          
                            </div>
                        </div>
                    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

	<?php echo e($users->links()); ?>	
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5489657/public_html/resources/views/admin/user.blade.php ENDPATH**/ ?>