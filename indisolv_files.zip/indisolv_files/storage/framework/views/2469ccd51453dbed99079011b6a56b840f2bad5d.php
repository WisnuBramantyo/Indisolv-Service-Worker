
<style type="text/css">
    .category-wrapper {
        padding-top:70px;
    }

    @media(min-width:768px) {
    .category-wrapper {
        padding: 50px;
        width:100%;
        background: #ea2e49;
    }

</style>
<!-- <link href="<?php echo e(asset('css/media_query.css')); ?>" rel="stylesheet" type="text/css"/> -->
<link href="<?php echo e(asset('css/style_1.css')); ?>" rel="stylesheet" type="text/css"/>

<?php $__env->startSection('content'); ?>
<div class="category-wrapper"></div> 
     <section id="blog" data-stellar-background-ratio="0.5">
          <div class="container">

        <div class="row">
            <div class="col-md-12 col-sm-12 animate-box" data-animate-effect="fadeInLeft">
                 <div class="section-title">
                      <h2>Online Article</h2>
                      <span class="line-bar">...</span>
                 </div>
            </div>
        </div>
        <div class="row mx-0">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row" style="margin-bottom: 25px; margin-top:25px; background: #fff; -webkit-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); -moz-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); border-radius: 3px; text-align: left;">
                    <div class="col-md-5">
                        <div class="fh5co_hover_news_img">
                        <?php if($news->urlToImage != NULL): ?>
                            <div class="fh5co_news_img"><img src="<?php echo e(url($news->urlToImage)); ?>" alt=""/></div>
                        <?php else: ?>
                            <div class="fh5co_news_img"><img src="" alt=""/></div>
                        <?php endif; ?>
                        <div></div>
                        </div>
                    </div>
                    <div class="col-md-7 animate-box">
                        <h4><a href="<?php echo e(url($news->url)); ?>"><?php echo e($news->title); ?></a></h4>
                        <small><i class="fa fa-clock-o"></i> <?php echo e($news->author . ' - ' .date('d M y', strtotime($news->publishedAt))); ?></small>
                        <?php if($news->content != NULL): ?>
                        <p style="font-size: 0.9em;"> <?php echo e(substr($news->content, 0, 260) . '...'); ?> </p>
                        <?php elseif($news->description != NULL): ?>
                        <p> <?php echo e($news->description); ?> </p>
                        <?php else: ?>
                        <p> No Description. </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-4 col-sm-4 section-title">
                <h3>Tags</h3>
                <span class="line-bar">___</span>
            </div>
            <div class="fh5co_tags_all">
                <a href="<?php echo e(url('inditutorial')); ?>" class="fh5co_tagg">Tutorial</a>
                <?php if(Request::url() === url('category/indihome')): ?>
                <a href="<?php echo e(url('category/indihome?page=1')); ?>" class="fh5co_tagg" style="background-color: #ea2e49">Indihome</a>
                <?php else: ?>
                <a href="<?php echo e(url('category/indihome?page=1')); ?>" class="fh5co_tagg">Indihome</a>
                <?php endif; ?>
                <?php if(Request::url() === url('category/technology')): ?>
                <a href="<?php echo e(url('category/technology?page=1')); ?>" class="fh5co_tagg" style="background-color: #ea2e49">Teknologi</a>
                <?php else: ?>
                <a href="<?php echo e(url('category/technology?page=1')); ?>" class="fh5co_tagg">Teknologi</a>
                <?php endif; ?>
                <?php if(Request::url() === url('category/internet')): ?>
                <a href="<?php echo e(url('category/internet?page=1')); ?>" class="fh5co_tagg" style="background-color: #ea2e49">Internet</a>
                <?php else: ?>
                <a href="<?php echo e(url('category/internet?page=1')); ?>" class="fh5co_tagg">Internet</a>
                <?php endif; ?>
                <?php if(Request::url() === url('category/telepon')): ?>
                <a href="<?php echo e(url('category/telepon?page=1')); ?>" class="fh5co_tagg" style="background-color: #ea2e49">Telepon</a>
                <?php else: ?>
                <a href="<?php echo e(url('category/telepon?page=1')); ?>" class="fh5co_tagg">Telepon</a>
                <?php endif; ?>
                <?php if(Request::url() === url('category/tv')): ?>
                <a href="<?php echo e(url('category/tv?page=1')); ?>" class="fh5co_tagg" style="background-color: #ea2e49">TV</a>
                <?php else: ?>
                <a href="<?php echo e(url('category/tv?page=1')); ?>" class="fh5co_tagg">TV</a>
                <?php endif; ?>
            </div>
        </div>
        <div class="row mx-0">
            <div class="col-12 text-center pb-4 pt-4">
                <a href="<?php echo e(url()->current() . '?page=1'); ?>" class="btn_pagging">1</a>
                <a href="<?php echo e(url()->current() . '?page=2'); ?>" class="btn_pagging">2</a>
                <a href="<?php echo e(url()->current() . '?page=3'); ?>" class="btn_pagging">3</a>
                <a href="<?php echo e(url()->current() . '?page=4'); ?>" class="btn_pagging">4</a>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/main.js')); ?>"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7935980/public_html/resources/views/category.blade.php ENDPATH**/ ?>