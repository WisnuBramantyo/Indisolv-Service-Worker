
<style type="text/css">
</style>
<?php $__env->startSection('content'); ?>
    <section id="tutorial" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">

                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2></h2>
                              <!-- <span class="line-bar">...</span> -->
                         </div>
                    </div>

                    <div class="col-md-12 col-sm-12">
                        
                        <!-- CONTACT FORM HERE -->
                        <form id="contact-form" role="form" action="<?php echo e(route('login')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                              <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="email" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;"><?php echo e(__('E-Mail Address')); ?></label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                              </div>

                              <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="password" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;"><?php echo e(__('Password')); ?></label>
                                </div>

                                <div class="col-md-8 col-sm-6">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                              </div>
                              <div class="form-group row">
                                <div class="col-md-12 col-sm-12">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> style="height: 0px;">

                                        <label class="form-check-label" for="remember" style="vertical-align: middle; padding-top: 15px; padding-bottom: 15px;color: white;">
                                            <?php echo e(__('Remember Me')); ?>

                                        </label>
                                    </div>
                                </div>
                              </div>
                              <div class="form-group row">
                                  <div class="col-md-offset-4 col-md-4 col-sm-12">
                                       <input type="submit" class="form-control" name="submit" value="<?php echo e(__('Login')); ?>">
                                  </div>
                              </div>
                              <div class="form-group row col-md-offset-4 col-md-4 col-sm-12">
                                <a class="btn btn-link" href="<?php echo e(route('register')); ?>" style="color: white;" onMouseOver="this.style.color='#F00'" onMouseOut="this.style.color='#fff'">
                                    Doesn't have account?
                                </a>
                              </div>

                         </form>
                    </div>
               </div>
          </div>
     </section>
      <!-- FOOTER -->
     <footer data-stellar-background-ratio="0.5" style="padding-top: 10px; padding-bottom: 10px;">
          <div class="container">
             <div class="footer-bottom" style="margin-top: 1.5em;">
                  <div class="col-md-6 col-sm-5">
                       <div class="copyright-text"> 
                            <p>Copyright &copy; 2020 Indisolv</p>
                       </div>
                  </div>
                  <div class="col-md-6 col-sm-7">
                       <div class="phone-contact"> 
                            <p><span>Your Solutive Assistant</span></p>
                       </div>
                       <ul class="social-icon">
                            <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                            <li><a href="#" class="fa fa-twitter"></a></li>
                            <li><a href="#" class="fa fa-instagram"></a></li>
                       </ul>
                  </div>
             </div>
          </div>
     </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7935980/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>