

<?php $__env->startSection('content'); ?>

<div class="container">
<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Category</th>
      <th scope="col">Author</th>
      <th scope="col">Description</th>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr> 
      <th scope="row"><a href="<?php echo e(url('/article/'.$article->id)); ?>"><?php echo e($article -> title); ?></a></th>
      <td><?php echo e($article -> category); ?></td>
      <td><?php echo e($article -> author); ?></td>
      <td><?php echo e($article -> description); ?></td>
      <td><a href="<?php echo e(action('DashboardController@editArticle', $article->id)); ?>"><button type="button" class="btn btn-warning">Edit</button></a></td>
        <td><center><a class="btn btn-danger" data-placement="bottom" title="Hapus Data" data-toggle="modal" href="#" data-target="#modaldelete<?php echo $article->id;?>">Delete</a></td>
    </tr>

     <div class="modal fade" id="modaldelete<?php echo $article->id;?>" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <input type="hidden" value="<?php echo $article->id;?>" name="id">
                                    <h5>Apakah Anda yakin akan menghapus data ini?</h5>
                                </div>
                                <div class="modal-footer">
                                    <a class="btn btn-info btn-simple pull-left" style="width:60px" title="Kembali" data-dismiss="modal">Tidak</a>
                                    <a class="btn btn-danger btn-simple pull-right" style="width:60px" title="Hapus" href="<?php echo e(action('DashboardController@delete', $article->id)); ?>">Ya</a>
                                </div>
                          
                            </div>
                        </div>
                    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

	<?php echo e($articles->links()); ?>	
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7935980/public_html/resources/views/dashboard.blade.php ENDPATH**/ ?>