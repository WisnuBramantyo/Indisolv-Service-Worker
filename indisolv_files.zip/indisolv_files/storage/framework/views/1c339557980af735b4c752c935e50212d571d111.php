

<?php $__env->startSection('content'); ?>
<div class="container-fluid pb-4 pt-4 paddding">
    <div class="container paddding">
        <div class="row mx-0">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4"><?php echo e($title); ?></div>
                </div>


                 <?php $__currentLoopData = $indiarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indiarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row pb-4">
                    <div class="col-md-5">
                        <div class="fh5co_hover_news_img">
                            <div class="fh5co_news_img"><img src="<?php echo e(asset($indiarticle->urlToImage)); ?>" alt=""/></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="col-md-7 animate-box">
                        <a href="<?php echo e(url('/article/'. $indiarticle->id)); ?>" class="fh5co_magna py-2"> <?php echo e($indiarticle->title); ?> </a>
                        <br>
                         <a href="#" class="fh5co_mini_time py-3"> <?php echo e($indiarticle->author); ?> -
                        <?php echo e($indiarticle -> created_at); ?> </a>
                        <div class="fh5co_consectetur"> <?php echo e($indiarticle->description); ?>

                        </div>
                    </div>
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <hr>
                <div class="row d-flex justify-content-center">
                    <div class="col-md-6">
                        <?php echo e($indiarticles->links()); ?>

                </div>

</div>
            </div>
            <div class="col-md-3 animate-box" data-animate-effect="fadeInRight">
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">Tags</div>
                </div>
                <div class="clearfix"></div>
                <div class="fh5co_tags_all">
                    <a href="<?php echo e(url('category/technology?page=1')); ?>" class="fh5co_tagg">Teknologi</a>
                    <a href="<?php echo e(url('category/entertainment?page=1')); ?>" class="fh5co_tagg">Hiburan</a>
                    <a href="<?php echo e(url('category/science?page=1')); ?>" class="fh5co_tagg">Pengetahuan</a>
                    <a href="<?php echo e(url('category/travel?page=1')); ?>" class="fh5co_tagg">Traveling</a>
                    <a href="<?php echo e(url('category/fashion?page=1')); ?>" class="fh5co_tagg">Gaya Hidup</a>
                    <a href="<?php echo e(url('category/sport?page=1')); ?>" class="fh5co_tagg">Olahraga</a>
                    <a href="<?php echo e(url('category/health?page=1')); ?>" class="fh5co_tagg">Kesehatan</a>
                    <a href="<?php echo e(url('category/vehicles?page=1')); ?>" class="fh5co_tagg">Otomotif</a>
                </div>
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom pt-3 py-2 mb-4">Most Recent</div>
                </div>

                <?php $__currentLoopData = $recentarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row pb-3">
                    <div class="col-5 align-self-center">
                        <img src="<?php echo e(asset($recentarticle->urlToImage)); ?>" alt="img" class="fh5co_most_trading"/>
                    </div>
                    <div class="col-7 paddding">
                        <div class="most_fh5co_treding_font"><a style="color: black" href="<?php echo e(url('/article/'.$recentarticle->id)); ?>"><?php echo e($recentarticle->title); ?></a>
                        </div>
                        <div class="most_fh5co_treding_font_123"><?php echo e($recentarticle->created_at); ?></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5489657/public_html/resources/views/indi/indiarticle.blade.php ENDPATH**/ ?>