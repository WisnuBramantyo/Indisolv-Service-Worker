<style type="text/css">
    .left {
        float: left;
        width: 65%;
    }
    .right {
        float: right;
        width: 35%;
        padding-top: 40px;
        padding-left: 40px;
        padding-right: 40px;
    }
    .headerimage {
        max-width: 100%;
        height: auto;
    }
    .group:after {
        content:"";
        display: table;
        clear: both;
    }

    .categorytitle{
       color: white; 
    }

    .subheadline{
    }

    .maintitle{
        color: white;
        font-weight: bold;
    }

    .maincontent{
        color: white;
    }

    .homesubtitle{
        color: white;
        font-weight: bold;
    }

    .divider{
        background-color: white;
        border-color: white; 
    }

    .headline{

    }

    @media  screen and (max-width: 480px) {
        .left, .right {
            float: none;
            width: auto;
        }
        .right{
            background-color: white;
            padding: 0px;
        }

        .maintitle{
            color: white;
            font-size: 18pt;
        }

        .categorytitle{
            font-size: 12pt;
        }

        .headline{
            background-color: #bd0d14;
            padding: 20px;
        }

        .subheadline{
            padding-top: 20px;
            padding-right: 20px;
            padding-left: 20px;
        }

        .homesubtitle{
            color: #bd0d14;
        }

         .categorytitle{
            color: white;
         }

         .maincontent{
            display: none;
         }

        .divider{
            background-color: white;
            border-color: white; 
        }
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container-fluid paddding mb-5">
    <div class="group" style="background-color: #bd0d14">
    <div class="left">
        <a href="<?php echo e(url('/article/'.$newest->id)); ?>"><img width="100%" height="100%" class="headerimage" src="<?php echo e(asset($newest->urlToImage)); ?>" alt="" /> </a>
    </div>
    <div class="right">
            <div>
                <div class="headline">
                    <h5 class="categorytitle">News</h5>
                    <a href="<?php echo e(url('/article/'.$newest->id)); ?>"><h2 class="maintitle"><?php echo e($newest->title); ?></h2></a>
                    <p class="maincontent"><?php echo e($newest->description); ?></p>
                </div>
                <hr class="divider">
                <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="subheadline">
                     <h7 class="homesubtitle" style="font-weight: normal;" ><?php echo e($recent->category); ?></h7>
                    <a href="<?php echo e(url('/article/'.$recent->id)); ?>"><h6 class="homesubtitle"><?php echo e($recent->title); ?></h6></a>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

            </div>
    </div>
</div>
</div>
<div class="container-fluid pt-3">
    <div class="container animate-box" data-animate-effect="fadeIn">
        <div>
            <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">IndiTutorial</div>
        </div>
        <div class="owl-carousel owl-theme js" id="slider1">
            
            <?php $__currentLoopData = $tutorials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutorial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>         
            <div class="item px-2">
                <div class="fh5co_latest_trading_img_position_relative">
                    <div class="fh5co_latest_trading_img"><img src="<?php echo e(asset($tutorial->urlToImage)); ?>" alt=""
                                                           class="fh5co_img_special_relative"/></div>
                    <div class="fh5co_latest_trading_img_position_absolute"></div>
                    <div class="fh5co_latest_trading_img_position_absolute_1">
                        <a href="<?php echo e(url('/article/'.$tutorial->id)); ?>" class="text-white"> <?php echo e($tutorial -> title); ?> </a>
                        <div class="fh5co_latest_trading_date_and_name_color"> <?php echo e($tutorial->author); ?> - <?php echo e($tutorial->created_at); ?></div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<div class="container-fluid pb-4 pt-5">
    <div class="container animate-box">
        <div>
            <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">IndiInsider</div>
        </div>
        <div class="owl-carousel owl-theme" id="slider2">
            <?php $__currentLoopData = $insiders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item px-2">
                <div class="fh5co_hover_news_img">
                    <div class="fh5co_news_img"><img src="<?php echo e(asset( $insider->urlToImage)); ?>" alt=""/></div>
                    <div>
                        <a href="<?php echo e(url('/article/'.$insider->id)); ?>" class="d-block fh5co_small_post_heading"><span class=""><?php echo e($insider->title); ?></span></a>
                        <div class="c_g"><i class="fa fa-clock-o"></i> Oct 16,2017</div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="container-fluid pb-4 pt-4 paddding">
    <div class="container paddding">
        <div class="row mx-0">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">Teknologi</div>
                </div>


                 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indiarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row pb-4">
                    <div class="col-md-5">
                        <div class="fh5co_hover_news_img">
                            <div class="fh5co_news_img"><img src="<?php echo e(asset($indiarticle->urlToImage)); ?>" alt=""/></div>
                            <div></div>
                        </div>
                    </div>
                    <div class="col-md-7 animate-box">
                        <a href="<?php echo e(url($indiarticle->url)); ?>" class="fh5co_magna py-2"> <?php echo e($indiarticle->title); ?> </a><br>
                        <a href="#" class="fh5co_mini_time py-3"> <?php echo e($indiarticle->author . ' - ' . date('d M y', strtotime($indiarticle->publishedAt))); ?> </a>
                        <?php if($indiarticle->content != NULL): ?>
                        <div class="fh5co_consectetur"> <?php echo e(substr($indiarticle->content, 0, 260) . '...'); ?> </div>
                        <?php elseif($indiarticle->description != NULL): ?>
                        <div class="fh5co_consectetur"> <?php echo e($indiarticle->description); ?> </div>
                        <?php else: ?>
                        <div class="fh5co_consectetur"> No Description. </div>
                        <?php endif; ?>
                    </div>
                </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <hr>
                <div class="row d-flex justify-content-center">
                    <div class="col-md-6">
                </div>

</div>
            </div>
            <div class="col-md-3 animate-box" data-animate-effect="fadeInRight">
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">Tags</div>
                </div>
                <div class="clearfix"></div>
                <div class="fh5co_tags_all">
                    <a href="<?php echo e(url('category/technology?page=1')); ?>" class="fh5co_tagg">Teknologi</a>
                    <a href="<?php echo e(url('category/entertainment?page=1')); ?>" class="fh5co_tagg">Hiburan</a>
                    <a href="<?php echo e(url('category/science?page=1')); ?>" class="fh5co_tagg">Pengetahuan</a>
                    <a href="<?php echo e(url('category/travel?page=1')); ?>" class="fh5co_tagg">Traveling</a>
                    <a href="<?php echo e(url('category/fashion?page=1')); ?>" class="fh5co_tagg">Gaya Hidup</a>
                    <a href="<?php echo e(url('category/sport?page=1')); ?>" class="fh5co_tagg">Olahraga</a>
                    <a href="<?php echo e(url('category/health?page=1')); ?>" class="fh5co_tagg">Kesehatan</a>
                    <a href="<?php echo e(url('category/vehicles?page=1')); ?>" class="fh5co_tagg">Otomotif</a>
                </div>
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom pt-3 py-2 mb-4">Most Popular</div>
                </div>

                <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row pb-3">
                    <div class="col-5 align-self-center">
                        <img src="<?php echo e(asset($recentarticle->urlToImage)); ?>" alt="img" class="fh5co_most_trading"/>
                    </div>
                    <div class="col-7 paddding">
                        <div class="most_fh5co_treding_font"><a style="color: black" href="<?php echo e(url($recentarticle->url)); ?>"><?php echo e($recentarticle->title); ?></a>
                        </div>
                        <div class="most_fh5co_treding_font_123"><?php echo e($recentarticle->author . ' - ' . date('d M y', strtotime($recentarticle->publishedAt))); ?></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indimagz\resources\views/home.blade.php ENDPATH**/ ?>