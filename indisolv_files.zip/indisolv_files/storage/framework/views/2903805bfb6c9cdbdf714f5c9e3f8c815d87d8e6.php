
<style type="text/css">
    .tutorial-wrapper {
        padding-top:70px;
    }

    @media(min-width:768px) {
    .tutorial-wrapper {
        padding: 50px;
        width:100%;
        background: #ea2e49;
    }

</style>
<link href="<?php echo e(asset('css/style_1.css')); ?>" rel="stylesheet" type="text/css"/>

<?php $__env->startSection('content'); ?>
<div class="tutorial-wrapper"></div> 
     <!-- BLOG -->
     <section id="blog" data-stellar-background-ratio="0.5">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="section-title">
                              <h2><?php echo e($title); ?></h2>
                              <span class="line-bar">...</span>
                         </div>
                    </div>
                    <div class="row">
                        <div class="col-md-8 col-sm-8">
                          <div class="col-md-12 col-sm-12"> 
                            <?php if(!$indiarticles->isEmpty()): ?>
                            <?php $__currentLoopData = $indiarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $indiarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row" style="margin-bottom: 25px; margin-top:25px; background: #fff; -webkit-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); -moz-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); border-radius: 3px; text-align: left;">
                                <div class="col-md-5">
                                    <div class="fh5co_hover_news_img">
                                    <?php if($indiarticle->urlToImage != NULL): ?>
                                        <div class="fh5co_news_img"><img src="<?php echo e(asset($indiarticle->urlToImage)); ?>" alt="Article Image"/></div>
                                    <?php else: ?>
                                        <div class="fh5co_news_img"><img src="" alt="No Article Image"/></div>
                                    <?php endif; ?>
                                    <div></div>
                                    </div>
                                </div>
                                <div class="col-md-7 animate-box" style="margin-top: 25px; margin-bottom: 25px">
                                    <small><i class="fa fa-clock-o"></i> <?php echo e($indiarticle -> created_at); ?></small>
                                    <h3><a href="<?php echo e(url('/article/'. $indiarticle->id)); ?>"><?php echo e($indiarticle->title); ?></a></h3>
                                    <p> <?php echo e($indiarticle->description); ?> </p>
                                    <a href="<?php echo e(url('/article/'. $indiarticle->id)); ?>" class="btn section-btn">Read article</a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div class="row" style="margin-bottom: 25px; margin-top:25px; background: #fff; -webkit-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); -moz-box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); box-shadow: 0 1px 30px rgba(0, 0, 0, 0.1); border-radius: 3px; text-align: left;">
                                <div class="col-md-12 col-sm-12">
                                    <h3>Maaf pencarian tidak ditemukan</h3>
                                    <div class="fh5co_hover_news_img">
                                        <div class="fh5co_news_img" style="min-height: 300px;"><img src="<?php echo e(asset('images/sorry.jpg')); ?>" alt="Sorry Not Found" style="width: 100%;height: 100%;min-height: 300px;" /></div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                          </div>
                        </div>
                        <div class="col-md-4 col-sm-4 section-title">
                            <h3>Tags</h3>
                            <span class="line-bar">___</span>
                        </div>
                        <div class="fh5co_tags_all">
                            <?php if(Request::url() === url('inditutorial')): ?>
                            <a href="<?php echo e(url('inditutorial')); ?>" class="fh5co_tagg" style="background-color: #ea2e49">Tutorial</a>
                            <?php else: ?>
                            <a href="<?php echo e(url('inditutorial')); ?>" class="fh5co_tagg">Tutorial</a>
                            <?php endif; ?>
                            <a href="<?php echo e(url('category/indihome?page=1')); ?>" class="fh5co_tagg">Indihome</a>
                            <a href="<?php echo e(url('category/technology?page=1')); ?>" class="fh5co_tagg">Teknologi</a>
                            <a href="<?php echo e(url('category/internet?page=1')); ?>" class="fh5co_tagg">Internet</a>
                            <a href="<?php echo e(url('category/telepon?page=1')); ?>" class="fh5co_tagg">Telepon</a>
                            <a href="<?php echo e(url('category/useetv?page=1')); ?>" class="fh5co_tagg">UseeTV</a>
                        </div>
                        <div class="col-md-4 col-sm-4 section-title">
                            <h3>Most Recent</h3>
                            <span class="line-bar">___</span>
                        </div>
                        <div class="col-md-4 col-sm-4">
                         <?php $__currentLoopData = $recentarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="media blog-thumb" style="height: 100px">
                              <div class="media-body blog-info" style="padding: 10px; height: 50px;">
                                   <small><i class="fa fa-clock-o"></i> <?php echo e($recentarticle->created_at); ?></small>
                                   <h5><a href="<?php echo e(url('/article/'.$recentarticle->id)); ?>"><?php echo e($recentarticle->title); ?></a></h5>
                                   <!-- <p><?php echo e($recentarticle->description); ?>.</p> -->
                                   <!-- <a href="<?php echo e(url('/article/'.$recentarticle->id)); ?>" class="btn section-btn">Read article</a> -->
                              </div>
                         </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <?php echo e($indiarticles->links()); ?>

                        </div>
                    </div>
                        
               </div>
          </div>
     </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7935980/public_html/resources/views/indi/indiarticle.blade.php ENDPATH**/ ?>