

<?php $__env->startSection('content'); ?>
<div class="container-fluid pb-4 pt-4 paddding">
    <div class="container paddding">
        <div class="row mx-0">
            <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
                <div>
                    <div class="fh5co_heading fh5co_heading_border_bottom py-2 mb-4">News</div>
                </div>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row pb-4">
                    <div class="col-md-5">
                        <div class="fh5co_hover_news_img">
                        <?php if($news->urlToImage != NULL): ?>
                            <div class="fh5co_news_img"><img src="<?php echo e(url($news->urlToImage)); ?>" alt=""/></div>
                        <?php else: ?>
                            <div class="fh5co_news_img"><img src="" alt=""/></div>
                        <?php endif; ?>
                        <div></div>
                        </div>
                    </div>
                    <div class="col-md-7 animate-box">
                        <a href="<?php echo e(url($news->url)); ?>" class="fh5co_magna py-2"> <?php echo e($news->title); ?> </a><br>
                        <a href="#" class="fh5co_mini_time py-3"> <?php echo e($news->author . ' - ' . date('d M y', strtotime($news->publishedAt))); ?> </a>
                        <?php if($news->content != NULL): ?>
                        <div class="fh5co_consectetur"> <?php echo e(substr($news->content, 0, 260) . '...'); ?> </div>
                        <?php elseif($news->description != NULL): ?>
                        <div class="fh5co_consectetur"> <?php echo e($news->description); ?> </div>
                        <?php else: ?>
                        <div class="fh5co_consectetur"> No Description. </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="row mx-0">
            <div class="col-12 text-center pb-4 pt-4">
                <!-- <a href="#" class="btn_mange_pagging"><i class="fa fa-long-arrow-left"></i>&nbsp;&nbsp; Previous</a> -->
                <a href="<?php echo e(url()->current() . '?page=1'); ?>" class="btn_pagging">1</a>
                <a href="<?php echo e(url()->current() . '?page=2'); ?>" class="btn_pagging">2</a>
                <a href="<?php echo e(url()->current() . '?page=3'); ?>" class="btn_pagging">3</a>
                <a href="<?php echo e(url()->current() . '?page=4'); ?>" class="btn_pagging">4</a>
                <!-- <a href="#" class="btn_mange_pagging">Next <i class="fa fa-long-arrow-right"></i>&nbsp;&nbsp; </a> -->
            </div>
        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5489657/public_html/resources/views/category.blade.php ENDPATH**/ ?>