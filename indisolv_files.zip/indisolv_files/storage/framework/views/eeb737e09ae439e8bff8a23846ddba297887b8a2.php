<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Create New IndiInsider</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                <form action="<?php echo e(route('store_insider')); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input required="required" value="" placeholder="Enter title here" type="text" name = "title"class="form-control" />   
                     </div>

                     <div class="form-group">
                        <label for="image">Header Image</label>
                        <input required="required" value="image" type="file" name ="image" id="image" class="form-control" />
                     </div>

                       <div class="form-group">
                          <label for="inputlg">Description</label>
                          <input class="form-control input-lg" id="inputlg" name="description" type="text">
                      </div>

                     <div class="form-group">
                        <label for="content">Content</label>
                        <textarea class="content" name="content"></textarea>
                     </div>

                    <div class="form-group">
                     <input type="submit" name='publish' class="btn btn-success pull-right" value = "Publish"/>
                     </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>
  tinymce.init({
    selector : "textarea.content",
    plugins : ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste"],
    toolbar : "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link",
    height:600
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indimagz\resources\views/admin/indiInsider.blade.php ENDPATH**/ ?>