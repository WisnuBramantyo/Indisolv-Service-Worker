<?php $__env->startSection('content'); ?>

<div class="container">

<div class="row">
 <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo e($total_visitor); ?></h3>

                <h5>Total Visitor</h5>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
 </div>

  <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo e($article_visitor); ?></h3>

                <h5>Article Visitor</h5>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
 </div>


  <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo e($web_visitor); ?></h3>

                <h5>Web Page Visitor (Not Article)</h5>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
 </div>

</div>

<table class="table table-striped table-dark">
  <thead style="color: yellow">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">Category</th>
      <th scope="col">Author</th>
      <th scope="col">Visitor</th>
    </tr>
  </thead>
  <tbody>
  	<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr> 
      <th scope="row"><a style="color: white" href="<?php echo e(url('/article/'.$article->id)); ?>"><?php echo e($article -> title); ?></a></th>
      <td><?php echo e($article -> category); ?></td>
      <td><?php echo e($article -> author); ?></td>
      <td>
      	<span style="padding-left: 25px; padding-right: 25px; background-color: blue" class="badge badge-secondary"><h5><?php echo e($article -> visitor); ?></h5></span></td>
    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

	<?php echo e($articles->links()); ?>	
 	
 	<br>
 </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\indimagz\resources\views/admin/page_analytic.blade.php ENDPATH**/ ?>