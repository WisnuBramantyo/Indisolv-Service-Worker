<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="no-js">
<head>
     <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo-small.png')); ?>" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo e(asset('css/media_query.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
          integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <link href="<?php echo e(asset('css/owl.carousel.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('css/owl.theme.default.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('css/style_1.css')); ?>" rel="stylesheet" type="text/css"/>
    <!-- Modernizr JS -->
    <script src="<?php echo e(asset('js/modernizr-3.5.0.min.js')); ?>"></script>

</head>
<style type="text/css">

    .uppernav{
        padding: 10px;
    }

    @media  screen and (max-width: 480px) {
        .uppernav{
            padding: 0px;
        }
    }
</style>

<body>
<div class="uppernav">
   <div class="container-fluid">
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-3">
                <img src="<?php echo e(asset('images/logo.png')); ?>" alt="img" class="fh5co_logo_width"/>
            </div>
            <div class="col-12 col-md-9 align-self-center fh5co_mediya_right">
                 <div class="text-center d-inline-block">
                    <a data-toggle="modal" data-target="#modalSearchForm" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-search"></i></div></a>
                </div>
                <div class="text-center d-inline-block">
                    <a href="#" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-twitter"></i></div></a>
                </div>
                <div class="text-center d-inline-block">
                    <a href="#" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-facebook"></i></div></a>
                </div>
                <?php if(auth()->guard()->guest()): ?>
                <div class="text-center d-inline-block">
                    <a href="<?php echo e(route('login')); ?>" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-sign-in"></i></div></a>
                </div>
                <?php else: ?>
                <div class="text-center d-inline-block">
                    <a data-toggle="modal" href="#" data-target="#modallogout" class="fh5co_display_table"><div class="fh5co_verticle_middle"><i class="fa fa-sign-out"></i></div></a>
                       <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                </div>

                  <div class="modal fade" id="modallogout" tabindex="-1" role="dialog">
                        <div class="modal-dialog modal-sm" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>

                                <div class="modal-body">
                                    <h5>Apakah anda ingin logout?</h5>
                                </div>
                                <div class="modal-footer">
                                    <a class="btn btn-info" style="width:60px" title="Kembali" data-dismiss="modal">Tidak</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();" > Ya</a>
                                </div>
                          
                            </div>
                        </div>
                    </div>

                <?php endif; ?>


                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    </div>
</div>

<div class="container-fluid bg-red fh5co_padd_mediya padding_786">
    <div class="container padding_786">
       <a class="navbar-brand pull-right" href="#">
    <img src="<?php echo e(asset('images/logo-small.png')); ?>" width="50" height="40" alt="">
  </a> 
        <nav class="navbar navbar-toggleable-md  navbar-light">

              <button style="border-color: rgba(255,255,255,0.5)" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('inditutorial')); ?>">Indi Tutorial<span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('indilifestyle')); ?>">Indi Lifestyle<span class="sr-only">(current)</span></a>
                    </li>

                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('indiinsider')); ?>">Indi Insider <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="dropdownMenuButton2" data-toggle="dropdown"
                           aria-haspopup="true" aria-expanded="false">Kategori<span class="sr-only">(current)</span></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink_1">
                            <a class="dropdown-item" href="<?php echo e(url('category/technology?page=1')); ?>">Teknologi</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/entertainment?page=1')); ?>">Hiburan</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/science?page=1')); ?>">Pengetahuan</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/travel?page=1')); ?>">Traveling</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/fashion?page=1')); ?>">Gaya Hidup</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/sports?page=1')); ?>">Olahraga</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/health?page=1')); ?>">Kesehatan</a>
                            <a class="dropdown-item" href="<?php echo e(url('category/vehicles?page=1')); ?>">Otomotif</a>
                        </div>
                    </li>

                     <li class="nav-item ">
                        <a class="nav-link" href="#">My News Feed<span class="sr-only">(current)</span></a>
                    </li>
<!--                     <li class="nav-item ">
                        <a class="nav-link" href="Contact_us.html">Contact <span class="sr-only">(current)</span></a>
                    </li> -->
                </ul>
            </div>
        </nav>
    </div>
</div>
            <?php echo $__env->yieldContent('content'); ?>


<!-- Footer -->
<div class="container-fluid fh5co_footer_bg pb-3">
    <div class="container animate-box">
        <div class="row">
            <div class="col-12 spdp_right py-5"><img src="<?php echo e(asset('images/white_logo.png')); ?>" alt="img" class="footer_logo"/></div>
            <div class="clearfix"></div>
<!--             <div class="col-12 col-md-4 col-lg-3">
                <div class="footer_main_title py-3"> About</div>
                <div class="footer_sub_about pb-3"> Lorem Ipsum is simply dummy text of the printing and typesetting
                    industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                    unknown printer took a galley of type and scrambled it to make a type specimen book.
                </div>
                <div class="footer_mediya_icon">
                    <div class="text-center d-inline-block"><a class="fh5co_display_table_footer">
                        <div class="fh5co_verticle_middle"><i class="fa fa-linkedin"></i></div>
                    </a></div>
                    <div class="text-center d-inline-block"><a class="fh5co_display_table_footer">
                        <div class="fh5co_verticle_middle"><i class="fa fa-google-plus"></i></div>
                    </a></div>
                    <div class="text-center d-inline-block"><a class="fh5co_display_table_footer">
                        <div class="fh5co_verticle_middle"><i class="fa fa-twitter"></i></div>
                    </a></div>
                    <div class="text-center d-inline-block"><a class="fh5co_display_table_footer">
                        <div class="fh5co_verticle_middle"><i class="fa fa-facebook"></i></div>
                    </a></div>
                </div>
            </div> -->
   <!--          <div class="col-12 col-md-3 col-lg-2">
                <div class="footer_main_title py-3"> Category</div>
                <ul class="footer_menu">
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Business</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Entertainment</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Environment</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Health</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Life style</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Politics</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; Technology</a></li>
                    <li><a href="#" class=""><i class="fa fa-angle-right"></i>&nbsp;&nbsp; World</a></li>
                </ul>
            </div> -->
<!--             <div class="col-12 col-md-5 col-lg-3 position_footer_relative">
                <div class="footer_main_title py-3"> Most Viewed Posts</div>
                <div class="footer_makes_sub_font"> Dec 31, 2016</div>
                <a href="#" class="footer_post pb-4"> Success is not a good teacher failure makes you humble </a>
                <div class="footer_makes_sub_font"> Dec 31, 2016</div>
                <a href="#" class="footer_post pb-4"> Success is not a good teacher failure makes you humble </a>
                <div class="footer_makes_sub_font"> Dec 31, 2016</div>
                <a href="#" class="footer_post pb-4"> Success is not a good teacher failure makes you humble </a>
                <div class="footer_position_absolute"><img src="<?php echo e(asset('images/footer_sub_tipik.png')); ?>" alt="img" class="width_footer_sub_img"/></div>
            </div> -->
<!--             <div class="col-12 col-md-12 col-lg-4 ">
                <div class="footer_main_title py-3"> Last Modified Posts</div>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/allef-vinicius-108153.jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/32-450x260.jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/download (1).jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/science-578x362.jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/vil-son-35490.jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/zack-minor-15104.jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/download.jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/download (2).jpg')); ?>" alt="img"/></a>
                <a href="#" class="footer_img_post_6"><img src="<?php echo e(asset('images/ryan-moreno-98837.jpg')); ?>" alt="img"/></a>
            </div> -->
        </div>
<!--         <div class="row justify-content-center pt-2 pb-4">
            <div class="col-12 col-md-8 col-lg-7 ">
                <div class="input-group">
                    <span class="input-group-addon fh5co_footer_text_box" id="basic-addon1"><i class="fa fa-envelope"></i></span>
                    <input type="text" class="form-control fh5co_footer_text_box" placeholder="Enter your email..." aria-describedby="basic-addon1">
                    <a href="#" class="input-group-addon fh5co_footer_subcribe" id="basic-addon12"> <i class="fa fa-paper-plane-o"></i>&nbsp;&nbsp;Subscribe</a>
                </div>
            </div>
        </div> -->
    </div>
</div>
<div class="container-fluid fh5co_footer_right_reserved">
    <div class="container">
        <div class="row  ">
            <div class="col-12 col-md-6 py-4 Reserved"> © Copyright 2019, All rights reserved. Design by <a href="http://indimagz.com" title="Free HTML5 Bootstrap templates">IndiMagz.com</a>. </div>
            <div class="col-12 col-md-6 spdp_right py-4">
                <a href="#" class="footer_last_part_menu">Home</a>
                <a href="#" class="footer_last_part_menu">About</a>
                <a href="#" class="footer_last_part_menu">Contact</a>
                <a href="#" class="footer_last_part_menu">Latest News</a></div>
        </div>
    </div>
</div>

<!-- End of Footer -->

<div class="modal fade" id="modalSearchForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h5 class="modal-title" align="text-center">Search Indi Article</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(route('search')); ?>" method="get" enctype="multipart/form-data">
      <div class="modal-body mx-3">
          <input type="text" name="keyword" required="true" id="keyword" class="form-control">
      </div>
      <div class="modal-footer d-flex justify-content-center">
                     <input type="submit" name='publish' class="btn btn-danger" value = "Search"/>
      </div>
  </form>
    </div>
  </div>
</div>


<div class="gototop js-top">
    <a href="#" class="js-gotop"><i class="fa fa-arrow-up"></i></a>
</div>


 <!-- Script -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js"
        integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js"
        integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn"
        crossorigin="anonymous"></script>
    <!-- Waypoints -->
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <!-- Main -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\indimagz\resources\views/layouts/theme.blade.php ENDPATH**/ ?>