

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Create New IndiLifestyle</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                <form action="<?php echo e(route('store_lifestyle')); ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input required="required" value="" placeholder="Enter title here" type="text" name = "title"class="form-control" />   
                     </div>

                     <div class="form-group">
                        <label for="image">Header Image</label>
                        <input required="required" value="image" type="file" name ="image" id="image" class="form-control" />
                     </div>

                       <div class="form-group">
                          <label for="inputlg">Description</label>
                          <input class="form-control input-lg" id="inputlg" name="description" type="text">
                      </div>
                    
                     <div class="form-group">
                        <label for="content">Content</label>
                        <textarea id="editor" class="content" name="content"></textarea>
                     </div>


                    <div class="form-group">
                     <input type="submit" name='publish' class="btn btn-success pull-right" value = "Publish"/>
                     </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
         <form>
  Title:<br>
  <input type="text" id="title" name="title"><br>
  Content:<br>
  <input type="text" id="content" name="content"><br>
  Url:<br>
  <input type="text" id="url" name="url"><br>
  Button Text:<br>
  <input type="text" id="button" name="button"><br>
</form> 
      </div>
      <div class="modal-footer">
        <button type="button" id="ok" class="btn btn-primary" data-dismiss="modal">Ok</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      </div>
    </div>
  </div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
<script>
 tinymce.init({
  selector: '#editor',
   plugins : ["advlist autolink lists link image charmap print preview anchor", "searchreplace visualblocks code fullscreen", "insertdatetime media table contextmenu paste"],
  toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link | undo redo | currentdate',
      height:600,
  content_css: [
    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
    '<?php echo e(URL::asset('css/bootstrap.css')); ?>'],
  
  setup: function(editor) {

    document.getElementById('ok').addEventListener('click', function() {
              var title = document.getElementById('title').value;
              var button = document.getElementById('button').value;
              var content = document.getElementById('content').value;
              var url = document.getElementById('url').value;
              var html = htmlElement(title, content, url, button);
              editor.insertContent(html);
      }, false);
    
    function htmlElement(title, content, url, button) {
      return '<div class="container" style="max-width:480px"><div class="card"><div class="card-header bg-light"><h5>'+title+'</h5></div><div class="card-body" style="margin:30px"><h5>'+content+'</h5><div align="center"><a href="'+url+'" target="_blank" class="btn btn-danger btn-lg">'+button+'</a></div></div></div></div><br><br><br><br><br>';
    }
    
    function insertDate() {
       $('#myModal').modal('show');
    }

    editor.addButton('currentdate', {
      text: 'Promotion',
      //image: 'http://p.yusukekamiyamane.com/icons/search/fugue/icons/calendar-blue.png',
      tooltip: "Insert Promotion Box",
      onclick: insertDate
    });
  }
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5489657/public_html/resources/views/admin/create_indilifestyle.blade.php ENDPATH**/ ?>