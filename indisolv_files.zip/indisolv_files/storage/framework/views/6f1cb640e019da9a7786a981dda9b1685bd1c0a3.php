
<!-- <style type="text/css">

        .articletitle{
            font-size: 48pt;
            color: white;
        }
        @media  screen and (max-width: 480px) {
        .articletitle{
            font-size: 32pt;
        }
    }
</style> -->
<link href="<?php echo e(asset('css/style_1.css')); ?>" rel="stylesheet" type="text/css"/>

<?php $__env->startSection('content'); ?>

<div class="single">
 <!-- BLOG HEADER -->
 <div id="fh5co-title-box" style="background: url('<?php echo e(asset($article->urlToImage)); ?>');background-position: 50% 90.5px; max-height: 480px" data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="page-title">
        <span><?php echo e($article->created_at); ?></span>
        <h3 class="articletitle" style="color: white; font-size: 2em;"><?php echo e($article->title); ?></h3>
    </div>
</div>
<div id="fh5co-single-content" class="container-fluid pb-4 pt-4 paddding">
    <div class="container paddding">
        <div class="row mx-0">
            <div class="col-md-8 col-sm-12">
              <div class="col-md-12 col-sm-12 animate-box" id='article-content-mo' data-animate-effect="fadeInLeft" style="font-family: sans-serif; margin-top: 20px;">
                  <?php echo $article->content; ?>

              </div>
            </div>
            <div style="background-color: white" class="col-md-4 col-sm-4 section-title animate-box" data-animate-effect="fadeInRight">
                <div class="col-md-12 col-sm-12 section-title">
                    <h3>Tags</h3>
                    <span class="line-bar">___</span>
                </div>
                <div class="col-md-12 col-sm-12 fh5co_tags_all">
                    <a href="<?php echo e(url('inditutorial')); ?>" class="fh5co_tagg">Tutorial</a>
                    <a href="<?php echo e(url('category/indihome?page=1')); ?>" class="fh5co_tagg">Indihome</a>
                    <a href="<?php echo e(url('category/technology?page=1')); ?>" class="fh5co_tagg">Teknologi</a>
                    <a href="<?php echo e(url('category/internet?page=1')); ?>" class="fh5co_tagg">Internet</a>
                    <a href="<?php echo e(url('category/telepon?page=1')); ?>" class="fh5co_tagg">Telepon</a>
                    <a href="<?php echo e(url('category/useetv?page=1')); ?>" class="fh5co_tagg">UseeTV</a>
                </div>
                <div class="col-md-12 col-sm-12 section-title">
                    <h3>Most Recent</h3>
                    <span class="line-bar">___</span>
                </div>
                <div class="col-md-12 col-sm-12">
                 <?php $__currentLoopData = $recents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="media blog-thumb" style="height: 100px">
                      <div class="media-body blog-info" style="padding: 10px; height: 50px;">
                           <small><i class="fa fa-clock-o"></i> <?php echo e($recent->created_at); ?></small>
                           <h5><a href="<?php echo e(url('/article/'.$recent->id)); ?>"><?php echo e($recent->title); ?></a></h5>
                      </div>
                 </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

 <!-- FOOTER -->
 <footer data-stellar-background-ratio="0.5" style="margin-top:0px; padding-top: 0px;">
      <div class="container">
           <div class="row">        

                <div class="col-md-12 col-sm-12">
                     <div class="footer-bottom">
                          <div class="col-md-6 col-sm-5">
                               <div class="copyright-text"> 
                                    <p>Copyright &copy; 2020 IndiSolv</p>
                               </div>
                          </div>
                          <div class="col-md-6 col-sm-7">
                               <div class="phone-contact"> 
                                    <p>Chat IndiSolv <span>AI-Powered Bot</span></p>
                               </div>
                               <ul class="social-icon">
                                    <li><a href="#" class="fa fa-facebook-square" attr="facebook icon"></a></li>
                                    <li><a href="#" class="fa fa-twitter"></a></li>
                                    <li><a href="#" class="fa fa-instagram"></a></li>
                               </ul>
                          </div>
                     </div>
                </div>
                
           </div>
      </div>
 </footer>

<!-- Parallax -->
<script src="<?php echo e(asset('js/jquery.stellar.min.js')); ?>"></script>

<script>if (!navigator.userAgent.match(/Android|BlackBerry|iPhone|iPad|iPod|Opera Mini|IEMobile/i)){$(window).stellar();}</script>
<script type="text/javascript">
    window.onload = function(){
        $('#article-content-mo p').css('font-size','1.1em').css('font');
        $('#article-content-mo h2').css('font-size','1.5em');
        $('#article-content-mo ul li').css('font-size','1.1em').css('color','#757575');
        $('#article-content-mo h5').css('font-size','1.2em');
        // $('#article-content-mo img').wrap('<div class="" style=""></div>');
        $('#article-content-mo img').css('background-size','cover').css('width','100%');
    }

</script>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u7935980/public_html/resources/views/news.blade.php ENDPATH**/ ?>