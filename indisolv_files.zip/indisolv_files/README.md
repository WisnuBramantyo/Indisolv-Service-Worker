# How to install

create empty db indimagz

run command :

```
composer install
```

```
composer update
```

```
php artisan migrate
```

```
php artisan key:generate
```

```
npm install
```

```
npm run dev
```


register to create account


